import React from 'react';
import './App.css';
import WeatherDisplay from './components/WeatherDisplay';

function App() {
    return (
        <div className="App">
            <header className="App-header">
                <WeatherDisplay city="Toronto" />
            </header>
        </div>
    );
}

export default App;
