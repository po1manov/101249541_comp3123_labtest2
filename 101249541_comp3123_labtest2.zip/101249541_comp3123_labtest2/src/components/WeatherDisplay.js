import React, { useState, useEffect } from 'react';
import axios from 'axios';
import WeatherIcon from './WeatherIcon';

const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const WeatherDisplay = ({ city }) => {
    const [weeklyForecast, setWeeklyForecast] = useState([]);

    useEffect(() => {
        const API_KEY = '129db7af364a9d1444cea27281dd75fa'; // You should keep API keys secret
        const url = `http://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}`;

        axios.get(url)
            .then(response => {
                const dailyData = processWeeklyData(response.data.list);
                setWeeklyForecast(dailyData);
            })
            .catch(error => {
                console.error('Error fetching the weather data:', error);
            });
    }, [city]);

    const processWeeklyData = (data) => {
        const dailyForecast = new Map();

        data.forEach((forecast) => {
            const day = new Date(forecast.dt_txt).getDay();
            if (!dailyForecast.has(day)) {
                dailyForecast.set(day, []);
            }
            dailyForecast.get(day).push(forecast);
        });

        return Array.from(dailyForecast).map(([day, forecasts]) => {
            const avgTemp = forecasts.reduce((acc, curr) => acc + curr.main.temp, 0) / forecasts.length;
            return {
                dayName: dayNames[day],
                avgTemp,
                iconCode: forecasts[0].weather[0].icon
            };
        }).sort((a, b) => dayNames.indexOf(a.dayName) - dayNames.indexOf(b.dayName));
    };

    if (!weeklyForecast.length) return <div>Loading...</div>;

    return (
        <div>
            <h2 className="App-header">Weekly Weather Forecast in {city}</h2>
            {weeklyForecast.map((forecast, index) => (
                <div key={index} className="weather-card">
                    <div className="weather-day">{forecast.dayName}</div>
                    <div className="weather-temp">{forecast.avgTemp.toFixed(2)} K</div>
                    <WeatherIcon iconCode={forecast.iconCode} className="weather-icon" />
                </div>
            ))}
        </div>
    );
};

export default WeatherDisplay;
